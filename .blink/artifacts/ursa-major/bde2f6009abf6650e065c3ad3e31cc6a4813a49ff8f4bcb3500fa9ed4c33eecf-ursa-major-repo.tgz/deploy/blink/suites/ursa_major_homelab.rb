# frozen_string_literal: true

class UrsaMajorHomelabSuite < Blink::Testing::Suite
  suite_name "Ursa Major Homelab"

  WEB_BASE = "http://192.168.86.53:18080"
  C2_BASE  = "https://192.168.86.53:18443"

  test "web login page returns 200",
       tags: [:smoke, :health],
       desc: "Confirms the published web UI login page is reachable on the homelab LAN IP." do
    res = http.get("#{WEB_BASE}/auth/login")
    assert_status res, 200
    assert_body res, "Ursa"
    assert_body res, 'action="/auth/login"'
  end

  test "web static assets are served from the direct root path",
       tags: [:smoke, :health],
       desc: "Confirms the direct LAN deployment is not carrying a stale reverse-proxy base path." do
    res = http.get("#{WEB_BASE}/static/style.css")
    assert_status res, 200
  end

  test "c2 health endpoint returns healthy json",
       tags: [:smoke, :health],
       desc: "Verifies the published C2 listener responds over TLS on the homelab LAN IP." do
    res = http.get("#{C2_BASE}/health")
    assert_status res, 200
    assert_body res, /healthy/
  end

  test "c2 container is running",
       tags: [:health],
       desc: "Checks that the C2 compose service is up and not restarting." do
    out = ssh_run("docker inspect --format '{{.State.Status}}' ursa-major-c2-1 2>/dev/null")
    assert_equal "running", out
  end

  test "web container is running",
       tags: [:health],
       desc: "Checks that the web compose service is up and not restarting." do
    out = ssh_run("docker inspect --format '{{.State.Status}}' ursa-major-web-1 2>/dev/null")
    assert_equal "running", out
  end

  test "c2 port is published on the lan address",
       tags: [:health],
       desc: "Confirms Docker published the TLS listener on 192.168.86.53:18443." do
    out = ssh_run("docker ps --filter name=^/ursa-major-c2-1$ --format '{{.Ports}}'")
    assert out.match?(/192\.168\.86\.53:18443->8443\/tcp/), "Unexpected C2 ports: #{out.inspect}"
  end

  test "web port is published on the lan address",
       tags: [:health],
       desc: "Confirms Docker published the UI on 192.168.86.53:18080." do
    out = ssh_run("docker ps --filter name=^/ursa-major-web-1$ --format '{{.Ports}}'")
    assert out.match?(/192\.168\.86\.53:18080->8080\/tcp/), "Unexpected web ports: #{out.inspect}"
  end
end
