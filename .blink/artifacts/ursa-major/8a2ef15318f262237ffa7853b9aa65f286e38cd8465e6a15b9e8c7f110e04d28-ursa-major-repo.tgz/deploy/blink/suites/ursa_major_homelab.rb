# frozen_string_literal: true

class UrsaMajorHomelabSuite < Blink::Testing::Suite
  suite_name "Ursa Major Homelab"

  def c2_base
    "https://192.168.86.53:18443"
  end

  test "c2 health endpoint returns healthy json",
       tags: [:smoke, :health],
       desc: "Verifies the published C2 listener responds over TLS on the homelab LAN IP." do
    res = http.get("#{c2_base}/health")
    assert_status res, 200
    assert_body res, /healthy/
  end

  test "c2 container is running",
       tags: [:health],
       desc: "Checks that the C2 compose service is up and not restarting." do
    out = ssh_run("docker inspect --format '{{.State.Status}}' ursa-major-c2-1 2>/dev/null")
    assert_equal "running", out
  end

  test "c2 port is published on the lan address",
       tags: [:health],
       desc: "Confirms Docker published the TLS listener on 192.168.86.53:18443." do
    out = ssh_run("docker ps --filter name=^/ursa-major-c2-1$ --format '{{.Ports}}'")
    assert out.match?(/192\.168\.86\.53:18443->8443\/tcp/), "Unexpected C2 ports: #{out.inspect}"
  end
end
