#!/usr/bin/env bash
set -euo pipefail

runtime_dir="{{runtime_dir}}"
config_dir="${runtime_dir}/config"
data_dir="${runtime_dir}/data"
staging_dir="${runtime_dir}/staging"
config_file="${config_dir}/ursa.yaml"
env_file="${runtime_dir}/.env"

mkdir -p "${config_dir}" "${data_dir}/tls" "${staging_dir}"

cat >"${env_file}" <<EOF
COMPOSE_PROJECT_NAME={{compose_project}}
URSA_RUNTIME_DIR={{runtime_dir}}
URSA_PUBLISH_HOST={{publish_host}}
URSA_C2_PORT={{c2_port}}
URSA_WEB_PORT={{web_port}}
URSA_IMAGE_NAME={{image_name}}
EOF

CONFIG_FILE="${config_file}" python3 - <<'PY'
import json
import os
import secrets
from pathlib import Path

try:
    import yaml  # type: ignore
except Exception:
    yaml = None

config_path = Path(os.environ["CONFIG_FILE"])
data = {}

if config_path.exists():
    raw = config_path.read_text().strip()
    if raw:
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            if yaml is not None:
                data = yaml.safe_load(raw) or {}

major = data.setdefault("major", {})
major["host"] = "0.0.0.0"
major["port"] = 8443
major["db_path"] = "/data/ursa.db"
major.setdefault("traffic_profile", "default")

tls = major.setdefault("tls", {})
tls["enabled"] = True
tls["hostname"] = "{{publish_host}}"
tls["extra_sans"] = ["{{publish_host}}"]
tls["cert_path"] = "/data/tls/cert.pem"
tls["key_path"] = "/data/tls/key.pem"

web = major.setdefault("web", {})
web["host"] = "0.0.0.0"
web["port"] = 8080
web["base_path"] = ""
auth = web.setdefault("auth", {})
auth.setdefault("session_secret", secrets.token_urlsafe(32))
auth.setdefault("bootstrap_username", "admin")
auth.setdefault("bootstrap_password", "change-me-now")
auth.setdefault("bootstrap_role", "admin")

governance = major.setdefault("governance", {})
governance.setdefault("bearclaw_mode", "local")
governance.setdefault("require_step_up_approval", False)
governance.setdefault("step_up_risks", ["high", "critical"])
governance.setdefault("approval_signing_key", secrets.token_urlsafe(32))

config_path.write_text(json.dumps(data, indent=2) + "\n")
PY

docker info >/dev/null
